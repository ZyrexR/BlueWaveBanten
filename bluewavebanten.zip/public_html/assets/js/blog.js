// =================================================================
// File: assets/js/blog.js (Versi Final & Aman dari Error NULL)
// =================================================================

// --- Variabel Global ---
let allArticles = []; // Menyimpan semua artikel dari API

// =================================================================
// BAGIAN 1: PEMANGGILAN API & PENGAMBILAN DATA
// =================================================================

/**
 * Mengambil semua data blog dari API dan menanganinya.
 * Menampilkan status loading dan pesan error jika terjadi.
 * @returns {Promise<Array>} Array berisi objek-objek artikel.
 */
async function loadAllBlogData() {
    const articlesGrid = document.getElementById('articlesGrid');
    const popularArticlesContainer = document.getElementById('popularArticles');
    const categoriesListContainer = document.getElementById('categoriesList');
    
    // Tampilkan loading state untuk semua section
    const loadingHtml = `<div class="col-span-full text-center py-12"><div class="spinner mx-auto mb-4"></div><p class="text-gray-600">Memuat artikel...</p></div>`;
    if (articlesGrid) articlesGrid.innerHTML = loadingHtml.replace('col-span-full', 'col-span-2');
    if (popularArticlesContainer) popularArticlesContainer.innerHTML = loadingHtml.replace('col-span-full', '');
    if (categoriesListContainer) categoriesListContainer.innerHTML = loadingHtml.replace('col-span-full', '');

    try {
        const response = await fetch('https://bluewavebanten.my.id/api/api.php?action=get_blog');
        if (!response.ok) throw new Error(`HTTP Error! Status: ${response.status}`);

        const result = await response.json();
        if (result.success && Array.isArray(result.data)) {
            return result.data;
        } else {
            throw new Error(result.message || 'Format data dari API tidak valid.');
        }
    } catch (error) {
        console.error('Gagal memuat data blog:', error);
        if (articlesGrid) {
             articlesGrid.innerHTML = `<div class="col-span-2 text-center py-12 text-red-500">
                <p class="font-semibold">Gagal memuat artikel dari server.</p>
                <p class="text-sm">Silakan coba lagi nanti.</p>
            </div>`;
        }
        return []; // Kembalikan array kosong jika gagal
    }
}


// =================================================================
// BAGIAN 2: FUNGSI-FUNGSI UNTUK MERENDER KONTEN (TAMPILAN)
// =================================================================

/**
 * Menampilkan artikel unggulan (featured) di bagian atas halaman.
 * @param {Array} articles - Array artikel yang sudah difilter (hanya yang 'published').
 */
function displayFeaturedArticle(articles) {
    if (articles.length === 0) return; // Keluar jika tidak ada artikel
    const featured = articles[0]; // Ambil artikel pertama sebagai unggulan
    
    const h2 = document.querySelector('.featured-article h2');
    const p = document.querySelector('.featured-article p');
    const authorSpan = document.getElementById('featuredArticleAuthor');
    const dateSpan = document.getElementById('featuredArticleDate');
    const img = document.querySelector('.featured-article img');
    const button = document.querySelector('.featured-article button');

    if (h2) h2.textContent = featured.judul;
    if (p) p.textContent = featured.excerpt || 'Baca lebih lanjut untuk menemukan detail menarik...';
    if (authorSpan) authorSpan.textContent = featured.penulis_name || 'Admin BlueWave';
    if (dateSpan) dateSpan.textContent = new Date(featured.created_at).toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric' });
    if (img) img.src = featured.gambar_url || 'https://via.placeholder.com/800x400.png?text=BlueWave+Banten';
    if (button) button.onclick = () => window.location.href = `blog-detail.html?id=${featured.id}`;
}

/**
 * Menampilkan daftar artikel di grid utama.
 * @param {Array} articles - Array artikel yang akan ditampilkan.
 */
function displayArticles(articles) {
    const container = document.getElementById('articlesGrid');
    if (!container) return;

    if (articles.length > 0) {
        container.innerHTML = articles.map(article => {
            
            // --- INI PERBAIKANNYA ---
            // Jika kategori NULL, gunakan "Tanpa Kategori"
            const kategori = (article.kategori || 'Tanpa Kategori').toUpperCase();
            // Jika excerpt NULL, gunakan konten. Jika konten NULL, gunakan string kosong.
            const deskripsi = (article.excerpt || article.konten || '').substring(0, 100) + '...';
            // ------------------------

            return `
            <div class="article-card bg-white rounded-2xl shadow-lg overflow-hidden group transition hover:shadow-xl cursor-pointer" 
                 onclick="window.location.href='blog-detail.html?id=${article.id}'">
                <div class="relative overflow-hidden">
                    <img src="${article.gambar_url || 'https://via.placeholder.com/500x300.png?text=Blog+Image'}" alt="${article.judul}" class="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300">
                </div>
                <div class="p-6">
                    <span class="text-xs font-semibold text-blue-600">${kategori}</span>
                    <h3 class="text-lg font-bold text-gray-800 my-2 line-clamp-2 group-hover:text-blue-700">
                        ${article.judul}
                    </h3>
                    <p class="text-gray-600 text-sm mb-4 line-clamp-3">
                        ${deskripsi}
                    </p>
                    <span class="font-semibold text-blue-600 text-sm">Baca Selengkapnya →</span>
                </div>
            </div>
        `;
        }).join('');
    } else {
        container.innerHTML = '<div class="col-span-2 text-center py-12 text-gray-500">Tidak ada artikel yang cocok dengan kriteria Anda.</div>';
    }
}

/**
 * Menampilkan 3 artikel terpopuler (berdasarkan urutan dari API) di sidebar.
 * @param {Array} articles - Array artikel yang sudah difilter 'published'.
 */
function displayPopularArticles(articles) {
    const container = document.getElementById('popularArticles');
    if (!container) return;

    const popular = articles.slice(0, 3);

    if (popular.length > 0) {
        container.innerHTML = popular.map(article => `
            <div class="flex items-start space-x-3 group cursor-pointer" onclick="window.location.href='blog-detail.html?id=${article.id}'">
                <div class="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
                    <img src="${article.gambar_url || 'https://via.placeholder.com/150'}" alt="${article.judul}" class="w-full h-full object-cover">
                </div>
                <div>
                    <h4 class="font-semibold text-gray-800 group-hover:text-blue-600 transition text-sm leading-tight line-clamp-2">
                        ${article.judul}
                    </h4>
                    <p class="text-gray-500 text-xs mt-1">${new Date(article.created_at).toLocaleDateString('id-ID')}</p>
                </div>
            </div>
        `).join('');
    } else {
        container.innerHTML = '<p class="text-gray-500 text-sm">Tidak ada artikel populer saat ini.</p>';
    }
}

/**
 * Menghitung dan menampilkan jumlah artikel per kategori di sidebar.
 * @param {Array} articles - Array semua artikel (termasuk draft) untuk penghitungan akurat.
 */
function displayCategories(articles) {
    const container = document.getElementById('categoriesList');
    if (!container) return;

    const categoryCounts = {};
    articles.forEach(article => {
        // --- INI PERBAIKANNYA (dari sebelumnya) ---
        const cat = (article.kategori || '').trim();
        // ----------------------------------------
        
        if (cat) { // Hanya hitung jika kategori tidak kosong
            categoryCounts[cat] = (categoryCounts[cat] || 0) + 1;
        }
    });

    const categories = Object.keys(categoryCounts);
    if (categories.length > 0) {
        container.innerHTML = categories.map(cat => `
            <div class="flex justify-between items-center py-2 border-b border-gray-100 last:border-b-0 cursor-pointer" onclick="filterByCategory('${cat}')">
                <span class="text-gray-700 hover:text-blue-600 transition">${cat}</span>
                <span class="bg-blue-100 text-blue-600 px-2 py-0.5 rounded-full text-xs font-semibold">${categoryCounts[cat]}</span>
            </div>
        `).join('');
    } else {
        container.innerHTML = '<p class="text-gray-500 text-sm">Tidak ada kategori yang tersedia.</p>';
    }
}

// =================================================================
// BAGIAN 3: LOGIKA FILTERING, PENCARIAN, DAN EVENT HANDLERS
// =================================================================

/**
 * Memfilter artikel berdasarkan kategori yang dipilih dan menampilkannya kembali.
 * @param {string} category - Nama kategori yang dipilih.
 */
function filterByCategory(category) {
    let filteredData;
    if (category === 'Semua Artikel') {
        filteredData = allArticles.filter(a => a.status === 'published');
    } else {
        // --- INI PERBAIKANNYA ---
        filteredData = allArticles.filter(article => 
            (article.kategori || '').trim() === category && article.status === 'published'
        );
        // ------------------------
    }
    displayArticles(filteredData);

    // Update tampilan tombol filter yang aktif
    document.querySelectorAll('.filter-btn').forEach(button => {
        const buttonCategory = button.textContent.trim().replace(/[\u{1F300}-\u{1F64F}]/gu, '').trim(); // Hapus emoji & spasi
        if (buttonCategory === category) {
            button.classList.add('active', 'bg-blue-600', 'text-white');
            button.classList.remove('bg-white', 'text-gray-700', 'border-2');
        } else {
            button.classList.remove('active', 'bg-blue-600', 'text-white');
            button.classList.add('bg-white', 'text-gray-700', 'border-2');
        }
    });
}

/**
 * Mencari artikel berdasarkan kata kunci di judul atau konten.
 */
function performSearch() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const filtered = allArticles.filter(article => {
        if (article.status !== 'published') return false;
        
        // --- INI PERBAIKANNYA ---
        const title = (article.judul || '').toLowerCase();
        const content = (article.konten || '').toLowerCase();
        // ------------------------

        return title.includes(searchTerm) || content.includes(searchTerm);
    });
    displayArticles(filtered);
}

/**
 * Mengatur semua event listener untuk interaksi pengguna.
 */
function setupEventListeners() {
    // Pemicu Mobile Menu
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const mobileMenu = document.getElementById('mobileMenu');
    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', () => mobileMenu.classList.toggle('hidden'));
    }

    // Pemicu Dropdown Header
    const dropdownButton = document.getElementById('destinasiDropdown');
    const dropdownMenu = document.getElementById('destinasiMenu');
    if (dropdownButton) {
        dropdownButton.addEventListener('click', (event) => {
            event.stopPropagation();
            dropdownMenu.classList.toggle('hidden');
        });
    }

    // Penutup Menu Universal (jika klik di luar)
    document.addEventListener('click', (event) => {
        if (mobileMenu && !mobileMenu.classList.contains('hidden') && !mobileMenuBtn.contains(event.target)) {
            mobileMenu.classList.add('hidden');
        }
        if (dropdownMenu && !dropdownMenu.contains(event.target) && !dropdownButton.contains(event.target)) {
            dropdownMenu.classList.add('hidden');
        }
    });

    // Pemicu Progress Bar saat scroll
    window.addEventListener('scroll', () => {
        const docHeight = document.documentElement.scrollHeight - window.innerHeight;
        const scrollPercent = (window.pageYOffset / docHeight) * 100;
        const progressBar = document.getElementById('readingProgress');
        if (progressBar) progressBar.style.width = `${scrollPercent}%`;
    });

    // Pemicu Tombol Filter Kategori
    document.querySelectorAll('.filter-btn').forEach(button => {
        button.addEventListener('click', function() {
            const category = this.textContent.trim().replace(/[\u{1F300}-\u{1F64F}]/gu, '').trim(); // Hapus emoji & spasi
            filterByCategory(category);
        });
    });

    // Pemicu Kotak Pencarian (Search Box)
    const searchInput = document.getElementById('searchInput');
    const searchButton = document.querySelector('.search-box button');
    if (searchInput) {
        searchInput.addEventListener('keyup', (e) => {
            if (e.key === 'Enter') performSearch();
        });
    }
    if (searchButton) searchButton.addEventListener('click', performSearch);
}


// =================================================================
// BAGIAN 4: TITIK MASUK UTAMA APLIKASI (INITIALIZATION)
// =================================================================

document.addEventListener('DOMContentLoaded', async () => {
    // 1. Ambil semua data dari API terlebih dahulu.
    allArticles = await loadAllBlogData();

    // 2. Filter artikel yang akan ditampilkan (hanya yang 'published').
    const publishedArticles = allArticles.filter(article => article.status === 'published');
    
    // 3. Render semua komponen halaman dengan data yang sudah siap.
    if (publishedArticles.length > 0) {
        displayFeaturedArticle(publishedArticles);
        displayArticles(publishedArticles);
        displayPopularArticles(publishedArticles);
    }
    // Kategori dihitung dari semua artikel
    displayCategories(allArticles);
    
    // 4. Setelah semua konten dirender, atur semua event listener.
    setupEventListeners();
});