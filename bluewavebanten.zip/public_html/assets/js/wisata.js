// =============================================================
// File: assets/js/wisata.js (REVISI TOTAL)
// =============================================================

// --- Variabel Global ---
let allWisata = [];
let filteredWisata = [];
let allMonitoringData = {}; // Cache untuk data JSON yang sudah di-load
let currentPage = 1;
const itemsPerPage = 9;

// Peta & Layer
let wisataMap = null;
let monitoringMap = null;
let markerClusterGroup = null;
let monitoringLayerGroup = null;
let markers = {}; // Untuk highlight

// Status Inisialisasi (agar tidak load berulang)
let isWisataTabInitialized = false;
let isMonitoringTabInitialized = false;

// Ikon Peta
const defaultIcon = new L.Icon.Default();
const highlightedIcon = L.icon({
    iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
    iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34], shadowSize: [41, 41]
});


// =============================================================
// --- KLASIFIKASI MONITORING (SESUAI PERMINTAAN ANDA) ---
// =============================================================

// Daftar file JSON di server Anda (dari screenshot cPanel)
const allJsonFiles = [
    'EVI_Easter_Point_Kabsa.json',
    'EVI_Karangantu.json',
    'EVI_Pulau_Panaitan.geojson',
    'EVI_pulau_Panjang.json',
    'EVI_Ujung_Kulon.json',
    'evicagaralam.json',
    'evipesisirpantai.json',
    'PesisirAtas_j.geojson',
    'PesisirBaawahh_j.geojson',
    'Pulau_sangiang_j.json',
    'Pulau_tunda.json',
    'PulauPanaitan_J.geojson',
    'UjungKulon_J.json'
];

// Logika untuk mengklasifikasikan file-file tersebut
const monitoringCategoryConfig = {
    'Semua Potensi': {
        files: allJsonFiles, // Ambil semua file
        icon: 'fas fa-layer-group',
        color: 'bg-gray-100 text-gray-700'
    },
    'Potensi Mangrove': {
        // Logika: Nama file mengandung "evi" (tidak peduli besar/kecil)
        files: allJsonFiles.filter(file => file.toLowerCase().includes('evi')),
        icon: 'fas fa-tree',
        color: 'bg-green-100 text-green-700'
    },
    'Potensi Snorkeling & Diving': {
        // Logika: Sisanya (semua file yang TIDAK mengandung "evi")
        files: allJsonFiles.filter(file => !file.toLowerCase().includes('evi')),
        icon: 'fas fa-water',
        color: 'bg-blue-100 text-blue-700'
    }
};


// =============================================================
// --- INISIALISASI UTAMA & LOGIKA TAB ---
// =============================================================

document.addEventListener('DOMContentLoaded', () => {
    setupGlobalEventListeners();
    handleHashChange(); // Periksa hash URL saat halaman dimuat
});

// Setup event listener global (header, nav, modal, dll)
function setupGlobalEventListeners() {
    // Navigasi Hash (Tab)
    window.addEventListener('hashchange', handleHashChange);
    document.querySelectorAll('.tab-link').forEach(link => {
        link.addEventListener('click', (e) => {
            document.getElementById('mobileMenu').classList.add('hidden');
        });
    });

    // Header Dropdown
    const dropdownBtn = document.getElementById('destinasiDropdown');
    const dropdownMenu = document.getElementById('destinasiMenu');
    if (dropdownBtn) {
        dropdownBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            dropdownMenu.classList.toggle('hidden');
        });
    }
    document.addEventListener('click', () => {
        if (dropdownMenu) dropdownMenu.classList.add('hidden');
    });

    // Mobile Menu
    document.getElementById('mobileMenuBtn').addEventListener('click', () => {
        document.getElementById('mobileMenu').classList.toggle('hidden');
    });

    // Tombol Scroll-to-Top (FAB)
    const fab = document.querySelector('.fab'); 
    if (fab) {
        window.addEventListener('scroll', () => {
            fab.style.display = (window.scrollY > 300) ? 'flex' : 'none';
        });
        fab.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
    }

    // Tombol Close Modal
    const closeModalButton = document.querySelector('.modal button[onclick="closeModal()"]');
    if (closeModalButton) {
        closeModalButton.addEventListener('click', closeModal);
    }
    document.getElementById('wisataModal').addEventListener('click', (e) => {
        if (e.target.id === 'wisataModal') closeModal();
    });
}

// Fungsi utama untuk routing Tab
function handleHashChange() {
    const hash = window.location.hash || '#wisata'; // Default ke #wisata
    
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.add('hidden'));
    
    if (hash === '#monitoring') {
        document.getElementById('monitoringContent').classList.remove('hidden');
        document.title = 'Monitoring Potensi Wisata - BlueWave Banten';
        if (!isMonitoringTabInitialized) {
            initMonitoringTab();
        } else {
            setTimeout(() => { if (monitoringMap) monitoringMap.invalidateSize(); }, 100);
        }
    } else {
        document.getElementById('wisataContent').classList.remove('hidden');
        document.title = 'Destinasi Wisata Bahari - BlueWave Banten';
        if (!isWisataTabInitialized) {
            initWisataTab();
        } else {
            setTimeout(() => { if (wisataMap) wisataMap.invalidateSize(); }, 100);
        }
    }
}

// =============================================================
// --- BAGIAN 1: LOGIKA TAB "WISATA BAHARI" ---
// =============================================================

async function initWisataTab() {
    if (isWisataTabInitialized) return;
    
    console.log("Inisialisasi Tab Wisata Bahari...");
    setupWisataEventListeners();
    allWisata = await loadAllWisataData();
    
    updateCategoryStats(allWisata); 
    initWisataMap();
    filterGrid(); 
    
    isWisataTabInitialized = true;
}

function setupWisataEventListeners() {
    document.getElementById('sortFilter').addEventListener('change', filterGrid);
    document.getElementById('loadMoreBtn').addEventListener('click', () => {
        currentPage++;
        renderWisataGrid();
    });
}

async function loadAllWisataData() {
    const grid = document.getElementById('wisataGrid');
    const loadingHtml = `<div class="col-span-full text-center py-12"><div class="spinner mx-auto mb-4"></div><p class="text-gray-600">Memuat destinasi wisata...</p></div>`;
    if (grid) grid.innerHTML = loadingHtml;

    try {
        const response = await fetch('/api/api.php?action=get_wisata');
        if (!response.ok) throw new Error(`HTTP Error: ${response.status}`);
        const result = await response.json();
        
        if (result.success && Array.isArray(result.data)) {
            console.log("Berhasil memuat data wisata:", result.data.length);
            return result.data.map(item => ({ 
                ...item, 
                harga_tiket: parseInt(item.harga_tiket || 0),
                rating: parseFloat(item.rating) || 4.5 
            }));
        }
        throw new Error('Format data tidak valid');
    } catch (error) {
        console.error("Gagal memuat data wisata:", error);
        grid.innerHTML = `<div class="col-span-full text-red-500 text-center font-semibold">Gagal memuat data.</div>`;
        return [];
    }
}

function updateCategoryStats(data) {
    const counts = { pantai: 0, pulau: 0, resort: 0, ekowisata: 0, pelabuhan: 0 };
    let totalRating = 0;

    data.forEach(w => {
        const kat = (w.kategori || '').toLowerCase();
        if (kat.includes('pantai')) counts.pantai++;
        if (kat.includes('pulau')) counts.pulau++;
        if (kat.includes('resort')) counts.resort++;
        if (kat.includes('ekowisata') || kat.includes('mangrove')) counts.ekowisata++;
        if (kat.includes('pelabuhan')) counts.pelabuhan++;
        totalRating += (w.rating || 0);
    });

    document.getElementById('totalDestinasi').textContent = data.length;
    document.getElementById('avgRating').textContent = (totalRating / data.length).toFixed(1);
    document.getElementById('statCountPantai').textContent = counts.pantai;
    document.getElementById('statCountPulau').textContent = counts.pulau;
    
    document.getElementById('countPantai').textContent = `${counts.pantai} Destinasi`;
    document.getElementById('countPulau').textContent = `${counts.pulau} Destinasi`;
    document.getElementById('countResort').textContent = `${counts.resort} Destinasi`;
    document.getElementById('countMangrove').textContent = `${counts.ekowisata} Destinasi`;
    document.getElementById('countPelabuhan').textContent = `${counts.pelabuhan} Destinasi`;
}

function filterGrid() {
    const sortValue = document.getElementById('sortFilter').value;
    let tempWisata = [...allWisata]; 

    switch (sortValue) {
        case 'rating': tempWisata.sort((a, b) => (b.rating || 0) - (a.rating || 0)); break;
        case 'price_low': tempWisata.sort((a, b) => a.harga_tiket - b.harga_tiket); break;
        case 'price_high': tempWisata.sort((a, b) => b.harga_tiket - a.harga_tiket); break;
        case 'name': default: tempWisata.sort((a, b) => a.nama.localeCompare(b.nama));
    }
    
    filteredWisata = tempWisata;
    currentPage = 1; 
    renderWisataGrid();
    updateWisataMapMarkers(filteredWisata);
}

// =============================================================
// --- PERBAIKAN RENDER KARTU WISATA (LEBIH INTERAKTIF) ---
// =============================================================
function renderWisataGrid() {
    const grid = document.getElementById('wisataGrid');
    const resultCountEl = document.getElementById('resultCount');
    const loadMoreContainer = document.getElementById('loadMoreContainer');
    
    const itemsToShow = filteredWisata.slice(0, currentPage * itemsPerPage);
    
    if (currentPage === 1) grid.innerHTML = ''; 
    
    if (itemsToShow.length === 0 && currentPage === 1) {
         grid.innerHTML = `<div class="col-span-full text-center text-gray-500">Tidak ada destinasi ditemukan.</div>`;
    } else {
        const newItems = filteredWisata.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);
        
        // Menggunakan kelas kustom dari wisata.css (bukan Tailwind)
        grid.innerHTML += newItems.map(item => {
            const priceFormatted = (item.harga_tiket || 0).toLocaleString('id-ID');
            return `
                <div id="card-${item.id}" class="wisata-card">
                    <a class="card-image-link" onclick="openModal(${item.id})">
                        <img src="${item.gambar_url || 'https://via.placeholder.com/400x300.png'}" alt="${item.nama}" class="card-image">
                        <div class="card-kategori">${item.kategori}</div>
                        <div class="card-rating">${item.rating} ★</div>
                    </a>
                    <div class="p-5">
                        <h3 class="card-title" onclick="openModal(${item.id})">${item.nama}</h3>
                        <p class="card-location"><i class="fas fa-map-marker-alt mr-2"></i>${item.lokasi}</p>
                        
                        <div class="flex justify-between items-center mt-4">
                            <p class="card-price">Rp ${priceFormatted}</p>
                            <button onclick="openModal(${item.id})" class="card-button">
                                Detail <i class="fas fa-arrow-right ml-1 text-xs"></i>
                            </button>
                        </div>
                    </div>
                </div>`;
        }).join('');
    }
    
    addCardEventListeners();
    resultCountEl.textContent = `Menampilkan ${itemsToShow.length} dari ${filteredWisata.length} destinasi`;
    loadMoreContainer.style.display = itemsToShow.length >= filteredWisata.length ? 'none' : 'block';
}

function initWisataMap() {
    if (wisataMap) return;
    wisataMap = L.map('wisataMap').setView([-6.20, 106.00], 9);
    
    const osmLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
    });
    const imageryLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        attribution: 'Tiles &copy; Esri'
    });
    const baseMaps = { "Peta Jalan": osmLayer, "Citra Satelit": imageryLayer };
    
    osmLayer.addTo(wisataMap);
    L.control.layers(baseMaps, null, { collapsed: true }).addTo(wisataMap);
    
    markerClusterGroup = L.markerClusterGroup();
    wisataMap.addLayer(markerClusterGroup);
    L.control.locate().addTo(wisataMap);
    setTimeout(() => wisataMap.invalidateSize(), 100);
}

function updateWisataMapMarkers(items) {
    if (!markerClusterGroup) return;
    markerClusterGroup.clearLayers();
    markers = {}; 
    
    items.forEach(item => {
        if (item.latitude && item.longitude) {
            const marker = L.marker([parseFloat(item.latitude), parseFloat(item.longitude)], { icon: defaultIcon });
            marker.bindPopup(`<b>${item.nama}</b><br><a href="#" onclick="openModal(${item.id}); return false;">Lihat Detail</a>`);
            markers[item.id] = marker;
            markerClusterGroup.addLayer(marker);
        }
    });
}

// =============================================================
// --- BAGIAN 2: LOGIKA MODAL & INTERAKSI PETA (WISATA) ---
// =============================================================

function addCardEventListeners() {
    document.querySelectorAll('.wisata-card').forEach(card => {
        card.addEventListener('mouseenter', () => highlightMarker(card.id, true));
        card.addEventListener('mouseleave', () => highlightMarker(card.id, false));
    });
}

function highlightMarker(cardId, shouldHighlight) {
    const id = cardId.split('-')[1];
    const marker = markers[id];
    if (!marker) return;

    marker.setIcon(shouldHighlight ? highlightedIcon : defaultIcon);
    if (shouldHighlight) {
        if (markerClusterGroup.getVisibleParent(marker) !== wisataMap) {
             markerClusterGroup.zoomToShowLayer(marker, () => marker.openPopup());
        } else {
             marker.openPopup();
        }
    } else {
        marker.closePopup();
    }
}

async function openModal(wisataId) {
    const modal = document.getElementById('wisataModal');
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';

    // Reset isi modal
    document.getElementById('modalTitle').textContent = 'Memuat...';
    document.getElementById('modalLocation').textContent = '...';
    document.getElementById('modalRating').textContent = '...';
    document.getElementById('modalViews').textContent = '...';
    document.getElementById('modalImage').src = 'https://via.placeholder.com/600x400.png?text=Memuat+Gambar...';
    document.getElementById('modalDescription').textContent = '...';
    document.getElementById('modalPrice').textContent = '...';
    document.getElementById('modalFasilitas').innerHTML = '<li>Memuat...</li>';
    document.getElementById('modalTips').innerHTML = '<li>Memuat...</li>';

    try {
        const response = await fetch(`/api/api.php?action=get_wisata&id=${wisataId}`);
        if (!response.ok) throw new Error('Data detail tidak ditemukan');
        const result = await response.json();
        if (!result.success) throw new Error(result.message);
        const data = result.data;
        
        document.getElementById('modalTitle').textContent = data.nama;
        document.getElementById('modalLocation').textContent = data.lokasi;
        document.getElementById('modalRating').textContent = `${data.rating || 4.5} ★`;
        document.getElementById('modalViews').textContent = `${(data.views || 1000).toLocaleString('id-ID')} views`;
        document.getElementById('modalImage').src = data.gambar_url || 'https_via.placeholder.com/600x400.png';
        document.getElementById('modalDescription').textContent = data.deskripsi;
        document.getElementById('modalPrice').textContent = `Rp ${(parseInt(data.harga_tiket) || 0).toLocaleString('id-ID')}`;
        
        let fasilitas = ['Tidak ada data fasilitas'];
        if (data.fasilitas) {
            try { fasilitas = JSON.parse(data.fasilitas); } catch (e) { fasilitas = data.fasilitas.split(','); }
        }
        let tips = ['Tidak ada data tips'];
         if (data.tips) {
            try { tips = JSON.parse(data.tips); } catch (e) { tips = data.tips.split(','); }
        }
        
        document.getElementById('modalFasilitas').innerHTML = fasilitas.map(f => `<li><i class="fas fa-check text-green-500 mr-2"></i>${f.trim()}</li>`).join('');
        document.getElementById('modalTips').innerHTML = tips.map(t => `<li><i class="fas fa-lightbulb text-yellow-500 mr-2"></i>${t.trim()}</li>`).join('');

        if (data.latitude && data.longitude) {
            fetchWeatherData(data.latitude, data.longitude);
        } else {
            document.getElementById('modalWeather').innerHTML = '<p>Data cuaca tidak tersedia.</p>';
        }

    } catch (error) {
        console.error("Gagal membuka modal:", error);
        document.getElementById('modalTitle').textContent = 'Gagal Memuat Data';
        document.getElementById('modalDescription').textContent = 'Terjadi kesalahan saat mengambil detail destinasi.';
    }
}

async function fetchWeatherData(lat, lon) {
    const weatherContainer = document.getElementById('modalWeather');
    const safetyContainer = document.getElementById('weatherSafety');
    weatherContainer.innerHTML = '<div class="spinner mx-auto"></div>';
    safetyContainer.innerHTML = '';
    
    const url = `/api/api.php?action=get_weather&lat=${lat}&lon=${lon}`;

    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error('Gagal memuat cuaca');
        const data = await response.json(); 
        if (data.cod != 200) throw new Error(data.message || 'Gagal memuat data cuaca');

        weatherContainer.innerHTML = `
            <div class="flex justify-between items-center py-2 border-b border-blue-100">
                <span class="text-gray-700">Cuaca:</span>
                <span class="font-semibold text-blue-600 flex items-center">
                    <img src="https://openweathermap.org/img/wn/${data.weather[0].icon}.png" class="w-6 h-6 mr-1" alt="icon">
                    ${data.weather[0].description}
                </span>
            </div>
            <div class="flex justify-between items-center py-2 border-b border-blue-100">
                <span class="text-gray-700">Suhu:</span>
                <span class="font-semibold text-blue-600">${data.main.temp.toFixed(1)} °C</span>
            </div>
            <div class="flex justify-between items-center py-2 border-b border-blue-100">
                <span class="text-gray-700">Kelembaban:</span>
                <span class="font-semibold text-blue-600">${data.main.humidity} %</span>
            </div>
            <div class="flex justify-between items-center py-2">
                <span class="text-gray-700">Angin:</span>
                <span class="font-semibold text-blue-600">${data.wind.speed.toFixed(1)} m/s</span>
            </div>
        `;

        if (data.wind.speed > 10 || data.weather[0].main === 'Rain' || data.weather[0].main === 'Thunderstorm') {
            safetyContainer.className = 'mt-4 p-3 rounded-lg text-center font-semibold bg-red-100 text-red-700';
            safetyContainer.innerHTML = '<i class="fas fa-exclamation-triangle mr-2"></i>Kondisi Cuaca Buruk. Harap berhati-hati.';
        } else {
            safetyContainer.className = 'mt-4 p-3 rounded-lg text-center font-semibold bg-green-100 text-green-700';
            safetyContainer.innerHTML = '<i class="fas fa-check-circle mr-2"></i>Kondisi Cuaca Aman untuk Berwisata.';
        }
    } catch (error) {
        console.error("Error fetching weather:", error);
        weatherContainer.innerHTML = `<p class="text-red-500 text-sm">${error.message}</p>`;
    }
}

function closeModal() {
    document.getElementById('wisataModal').style.display = 'none';
    document.body.style.overflow = 'auto';
}

// =============================================================
// --- BAGIAN 3: LOGIKA TAB "MONITORING WISATA" ---
// =============================================================

function initMonitoringTab() {
    if (isMonitoringTabInitialized) return;
    
    console.log("Inisialisasi Tab Monitoring...");
    initMonitoringMap();
    generateMonitoringControls();
    
    const allButton = document.querySelector('.layer-control-btn[data-category="Semua Potensi"]');
    if (allButton) {
        allButton.click();
    }
    
    isMonitoringTabInitialized = true;
}

function initMonitoringMap() {
    if (monitoringMap) return;
    
    const osmLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
    });
    const imageryLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        attribution: 'Tiles &copy; Esri'
    });

    monitoringMap = L.map('monitoringMap', {
        center: [-6.20, 106.00],
        zoom: 9,
        layers: [osmLayer] // Default peta jalan
    });
    
    const baseMaps = { "Peta Jalan": osmLayer, "Citra Satelit": imageryLayer };
    L.control.layers(baseMaps, null, { collapsed: true }).addTo(monitoringMap);

    monitoringLayerGroup = L.layerGroup().addTo(monitoringMap);
    L.control.locate().addTo(monitoringMap);
    setTimeout(() => monitoringMap.invalidateSize(), 100); 
}

// BUAT TOMBOL KLASIFIKASI (MANGROVE & SNORKELING)
function generateMonitoringControls() {
    const container = document.getElementById('monitoringLayerControls');
    if (!container) {
        console.error("Error: Element #monitoringLayerControls tidak ditemukan!");
        return;
    }
    container.innerHTML = ''; // Kosongkan loader

    Object.keys(monitoringCategoryConfig).forEach(categoryName => {
        const config = monitoringCategoryConfig[categoryName];
        const button = document.createElement('button');
        button.className = `layer-control-btn px-4 py-3 ${config.color} rounded-lg font-semibold hover:opacity-80 transition-all duration-200 flex items-center space-x-2`;
        button.dataset.category = categoryName;
        button.innerHTML = `
            <i class="${config.icon}"></i>
            <span>${categoryName} (${config.files.length})</span>
        `;
        
        button.addEventListener('click', function() {
            document.querySelectorAll('.layer-control-btn').forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            document.getElementById('monitoringMapTitle').textContent = `Peta Analisis: ${categoryName}`;
            fetchAndDisplayLayers(config.files, categoryName);
        });
        
        container.appendChild(button);
    });
}

// FETCH SEMUA FILE JSON DALAM SATU KLIK
async function fetchAndDisplayLayers(fileList, categoryName) {
    monitoringLayerGroup.clearLayers();
    
    const mapContainer = document.getElementById('monitoringMap');
    let loader = document.getElementById('map-loader-id');
    if (!loader) {
        loader = document.createElement('div');
        loader.id = 'map-loader-id';
        loader.className = 'map-loader'; 
        loader.innerHTML = '<div class="spinner"></div><p style="color:black; background:white; padding:5px; border-radius:5px;">Memuat data layer...</p>';
        mapContainer.appendChild(loader);
    }
    loader.style.display = 'block';

    let allFeatures = [];

    for (const fileName of fileList) {
        const cacheKey = fileName;
        
        try {
            if (!allMonitoringData[cacheKey]) {
                console.log(`Fetching: /file_json/${fileName}?v=1.1`); // Path sudah benar
                const response = await fetch(`/file_json/${fileName}?v=1.1`); // Tambahkan cache-busting
                if (!response.ok) throw new Error(`Gagal memuat ${fileName}`);
                allMonitoringData[cacheKey] = await response.json(); 
            }
            
            const features = allMonitoringData[cacheKey].features;
            if (features) {
                features.forEach(f => {
                    // Beri klasifikasi berdasarkan logika awal
                    if (fileName.toLowerCase().includes('evi')) {
                        f.properties.Klasifikasi = 'Potensi Mangrove';
                    } else {
                        f.properties.Klasifikasi = 'Potensi Snorkeling/Diving';
                    }
                });
                allFeatures = allFeatures.concat(features);
            }
            
        } catch (error) {
            console.error(error);
        }
    }
    
    loader.style.display = 'none';
    displayMonitoringFeatures(allFeatures);
}

// RENDER POLIGON KE PETA
function displayMonitoringFeatures(features) {
    if (!features || features.length === 0) {
        console.warn("Tidak ada 'features' untuk ditampilkan.");
        return;
    }
    
    let bounds = []; 

    features.forEach(feature => {
        const { properties, geometry } = feature;
        if (!properties || !geometry) return;
        
        const skor = properties.gridcode || 1;
        let color = '#ef4444'; // Kurang Layak (Skor 1-2)
        if (skor >= 4) color = '#16a34a'; // Sangat Layak (Skor 4-5)
        else if (skor === 3) color = '#f59e0b'; // Layak (Skor 3)

        const layer = L.geoJSON(feature, {
            style: {
                color: color,
                fillColor: color,
                fillOpacity: 0.5,
                weight: 2
            }
        });
        
        const popupContent = `
            <b>Area Potensi</b><br>
            Klasifikasi: ${properties.Klasifikasi || 'N/A'}<br>
            ID Area: ${properties.Id || properties.FID || 'N/A'}<br>
            <b>Skor Kelayakan: ${skor}</b>
        `;
        layer.bindPopup(popupContent);
        
        monitoringLayerGroup.addLayer(layer);
        
        try {
             bounds.push(layer.getBounds());
        } catch (e) {
            console.warn("Gagal mendapatkan bounds untuk satu fitur:", feature);
        }
    });
    
    if (bounds.length > 0) {
        monitoringMap.fitBounds(L.latLngBounds(bounds).pad(0.1));
    }
}